@echo off
cd /d "%~dp0"
java -jar CanchaPro.jar
pause
