# CanchaPro - Proyecto final de Programación 2

Aplicación de escritorio Java Swing para el Complejo Deportivo La 10.

## Requisitos
- Java 17 o superior (compilado y probado con OpenJDK 21).
- Windows, Linux o macOS con entorno gráfico.
- No requiere base de datos, internet ni bibliotecas externas.

## Ejecutar
**Windows:** doble clic en `Iniciar_Windows.bat` (Java debe estar instalado), o en terminal desde la carpeta CanchaPro: `java -jar CanchaPro.jar`.

**Linux/macOS:** desde la carpeta CanchaPro: `java -jar CanchaPro.jar`.

Si se ejecuta desde otra carpeta, los datos se crearán en `data/` de la carpeta de trabajo. Para fijar ruta: `java -Dcanchapro.data=/ruta/a/datos -jar CanchaPro.jar`.

## Compilar y probar
```bash
javac -encoding UTF-8 -d build src/canchapro/*.java
java -cp build canchapro.Pruebas
jar cfe CanchaPro.jar canchapro.Main -C build .
```

## Primer uso
1. La carpeta `data/` contiene las canchas y datos de demostración.
2. Abra `Clientes` para registrar o localizar un cliente.
3. Use `Nueva reserva`: el sistema valida disponibilidad y calcula precio automáticamente.
4. En `Reservas` se pueden cambiar estados o cancelar sin borrar el historial.
5. En `Pagos` registre abonos y consulte saldos.
6. En `Reportes` filtre y exporte el resumen.
7. En `Configuración` active la tienda; el cambio persiste en `config.properties`.

## Datos y restauración
Los datos se guardan automáticamente en `data/`. Para restaurar la demostración, cierre la aplicación, elimine los archivos dentro de `data/` y ejecute `java -cp build canchapro.DatosDemo data` (requiere carpeta `build/`, incluida). **Haga una copia de seguridad antes de borrar datos.**

Los archivos `.csv` contienen una cabecera y registros Java serializados codificados en Base64, uno por línea; no son CSV tabulares legibles por Excel. Esta decisión conserva íntegros los objetos y caracteres especiales, pero requiere la misma versión de clases para deserializar. No cargue archivos de origen desconocido: la deserialización Java solo es adecuada para datos confiables.

## Pruebas
`java -cp build canchapro.Pruebas` ejecuta 15 aserciones sobre reglas de negocio y persistencia en una carpeta temporal sin modificar datos reales.

## Estructura
- `src/canchapro/Model.java`: entidades y enumeraciones.
- `src/canchapro/Gestion.java`: reglas de negocio.
- `src/canchapro/Store.java`: persistencia.
- `src/canchapro/Interfaz.java`: Swing.
- `src/canchapro/Main.java`: punto de entrada.
- `src/canchapro/Pruebas.java`: pruebas automatizadas.
- `docs/UML.puml`: diagrama de clases PlantUML.
- `docs/Documento_tecnico.pdf`: explicación y resultados.

## Limitaciones conocidas
No incluye captura gráfica automática ni calendario visual semanal. Las ventas de tienda no se integran al saldo de cancha. Los archivos de persistencia son CSV de carga serializada, no columnas tabulares. La interfaz utiliza diálogos para formularios, con tablas para las vistas principales.

## NetBeans (versión corregida)
Abra **Archivo > Abrir proyecto** y seleccione la carpeta `CanchaPro`. Requiere JDK 17 o superior. Puede ejecutar con `ant run`, compilar con `ant jar` y probar con `ant test`. El ejecutable actualizado está en `dist/CanchaPro.jar`. La interfaz Swing se edita en `src/canchapro/Interfaz.java`; no se incluyen formularios `.form` del diseñador visual.

El precio de reserva toma las tarifas por franja horaria y las ajusta según el precio base de la cancha respecto a Q150/h. Los servicios se agregan a su precio completo. Las fechas anteriores al día actual no se aceptan para nuevas reservas. Los `.csv` conservan el formato serializado original por compatibilidad con los datos existentes; no son CSV tabulares.
