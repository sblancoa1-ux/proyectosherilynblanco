package canchapro;
import java.nio.file.*;import javax.swing.*;
public class Main {public static void main(String[] args){Path p=Paths.get(System.getProperty("canchapro.data","data"));SwingUtilities.invokeLater(()->new Interfaz(new Gestion(new Store(p))).setVisible(true));}}
