@echo off
cd /d "%~dp0"
java -jar CanchaPro.jar
if errorlevel 1 pause
